require("timers")
require("async")

local __tick = 0

function getTickCount()
    return __tick
end

function love.update(dt)
    __tick = __tick + dt*1000

    updateTimers()
end

local test = async(function(self)
    print("pre " .. getTickCount())

    local test = Promise(function(resolve, reject)
        setTimer(resolve, 1000, 1, "Hey")
    end)

    local result = self:await(test)
    print(test) -- "Promise <pending>"
    print(result, getTickCount()) -- "Hey"
    print(test, getTickCount()) -- "Promise <resolved>"
end)
test()